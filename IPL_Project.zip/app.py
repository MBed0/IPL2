from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import secrets

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'
db = SQLAlchemy(app)

admin_key = secrets.token_urlsafe(8)

class Visitor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ip = db.Column(db.String(100))
    user_agent = db.Column(db.String(300))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

@app.before_request
def log_visitor():
    if request.endpoint not in ['static'] and not request.path.startswith('/admin'):
        ip = request.remote_addr
        ua = request.headers.get('User-Agent')
        db.session.add(Visitor(ip=ip, user_agent=ua))
        db.session.commit()

@app.route('/')
def index():
    return render_template('index.html')

@app.route(f'/admin/{admin_key}')
def admin_panel():
    visitors = Visitor.query.order_by(Visitor.timestamp.desc()).all()
    return render_template('admin.html', visitors=visitors, admin_key=admin_key)

if __name__ == '__main__':
    app.run(debug=True)
